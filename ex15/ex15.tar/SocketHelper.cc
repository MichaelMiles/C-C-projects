// Chenyang Fang
// 1663051
// chenyf@uw.edu
// Copyright 2018 Chenyang Fang
// this file contains implementations
// of helper functions specified in the
// SocketHelper.h header files

#include "SocketHelper.h"

using namespace std;

bool LookupName(char* name,
                const unsigned short port,
                struct sockaddr_storage* ret_addr,
                size_t* ret_addrlen) {
    // create hints
    struct addrinfo hints, *results;
    int retval;

    // zero out fields in the hints
    memset(&hints, 0, sizeof(hints));
    // set some certain fields for hints
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    // do lookup by invoking getaddrinfo()
    retval = getaddrinfo(name, nullptr, &hints, &results);
    if (retval != 0) {
        // not successful
        cerr << "getaddrinfo failed: ";
        cerr << gai_strerror(retval) << endl;
        return false;
    }

    // set the port in the first result
    if (results->ai_family == AF_INET) {
        struct sockaddr_in* v4addr = (struct sockaddr_in*)results->ai_addr;
        v4addr->sin_port = htons(port);
    } else if (results->ai_family == AF_INET6) {
        struct sockaddr_in6* v6addr = (struct sockaddr_in6*)results->ai_addr;
        v6addr->sin6_port = htons(port);
    } else {
        cerr << "getaddrinfo failed to provide an IPv4 or IPv6 address";
        cerr << endl;
        // free addrinfo
        freeaddrinfo(results);
        return false;
    }

    // return the first result
    assert(results != nullptr);
    memcpy(ret_addr, results->ai_addr, results->ai_addrlen);
    *ret_addrlen = results->ai_addrlen;

    // free the addrinfo
    freeaddrinfo(results);
    return true;
}

bool Connect(const struct sockaddr_storage& addr,
            const size_t& addrlen,
            int* ret_fd) {
    // create the socket
    int socket_fd = socket(addr.ss_family, SOCK_STREAM, 0);
    if (socket_fd == -1) {
        cerr << "socket() failed: " << strerror(errno) << endl;
        return false;
    }

    // connect the socket to the remote host
    int res = connect(socket_fd,
                    reinterpret_cast<const struct sockaddr*>(&addr),
                    addrlen);
    if (res == -1) {
        cerr << "connect() failed" << strerror(errno) << endl;
        return false;
    }

    *ret_fd = socket_fd;
    return true;
}

int readHelper(int fd, char* buf, int len) {
    // for storing result
    int res;
    while (1) {
        res = read(fd, buf, len);
        if (res == -1) {
            if (errno == EINTR) {
                continue;
            }
        }
        break;
    }
    return res;
}

int writeHelper(int socket_fd, char* buf, int len) {
    int res;
    int written = 0;
    // continue writing util we have written
    // all the byte in the buf
    while (written < len) {
        res = write(socket_fd, buf + written, len - written);
        if (res == -1) {
            if (errno == EINTR) {
                continue;
            }
            // error
            // break and return
            return -1;
        }
        if (res == 0) {
            // close prematurely case
            return 0;
        }
        written += res;
    }
    return written;
}
