// Chenyang Fang
// 1663051
// chenyf@uw.edu
// Copyright 2018 Chenyang Fang
// This SocketHelper header files contains some declarations
// of some helper functions for a program that connect read and write
// to a remote server

#ifndef _SOCKETHELPER_H_
#define _SOCKETHELPER_H_

#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <cerrno>
#include <iostream>

// DNS lookup on the given name, and
// return through the given sockaddr_storage
// ret_addr. set the port to the given port and
// return the length of the struct sockaddr_ through
// the given ret_addrlen
// @return true on success, false on failure
bool LookupName(char* name,
                const unsigned short port,
                struct sockaddr_storage* ret_addr,
                size_t* ret_addrlen);


// helper function for connecting to the remote
// host and port given by the parameter addr and
// addrlen. return a connected socket through the
// given ret_socket
// @return true on success, false on failure
bool Connect(const struct sockaddr_storage& addr,
            const size_t& addrlen,
            int* ret_fd);

// helper function for reading len bytes from the given
// file descriptor fd into the given buf
// @return the result of bytes read from the fd
//         -1 on error
int readHelper(int fd, char* buf, int len);

// helper function for writing len bytes of the given buf
// into the given socket_fd
// @return number of bytes successfully written
//      on success the return value should be the same as len
//      on failure return -1 on write error and 0 on socket_fd
//      closed prematurely
int writeHelper(int socket_fd, char* buf, int len);

#endif  // _SOCKETHELPER_H_
