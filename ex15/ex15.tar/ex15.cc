// Chenyang Fang
// 1663051
// chenyf@uw.edu
// Copyright 2018 Chenyang Fang
// This program accepts three command line
// arguments: hostname of a server, the port number
// of that server and the name of a local file.
// Connect via TCP to the server o nthe supplied hostname and port
// and read bytes from the local file and write those bytes over the
// TCP connection.

#include <sys/socket.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>

#include "./SocketHelper.h"

#define BUF 256

using namespace std;

// Usage message
void Usage(char* progname) {
    cerr << "usage: " << progname << " hostname port filename" << endl;
    exit(EXIT_FAILURE);
}

int main(int argc, char** argv) {
    if (argc != 4) {
        // error on input from command line
        Usage(argv[0]);
    }
    // open the file
    int fd = open(argv[3], O_RDONLY);
    if (fd == -1) {
        // fail to open
        cerr << "Fail to open given file" << endl;
        Usage(argv[0]);
    }
    // get the port number
    unsigned short port = 0;
    if (sscanf(argv[2], "%hu", &port) != 1) {
        Usage(argv[0]);
    }

    // get sockaddr
    struct sockaddr_storage addr;
    size_t addrlen;
    if (!LookupName(argv[1], port, &addr, &addrlen)) {
        Usage(argv[0]);
    }

    // connect to the remote host
    int socket_fd;
    if (!Connect(addr, addrlen, &socket_fd)) {
        Usage(argv[0]);
    }

    // read from the file and write bytes through socket
    // to the remote host
    char readbuf[BUF];
    int res;
    int writeRes;
    while (1) {
        res = readHelper(fd, readbuf, BUF);
        if (res == 0) {
            // EOF
            break;
        } else if (res == -1) {
            // error
            cerr << "read error: " << endl;
            cerr << strerror(errno) << endl;
            close(socket_fd);
            close(fd);
            return EXIT_FAILURE;
        }

        writeRes = writeHelper(socket_fd, readbuf, res);
        if (writeRes == 0) {
            cerr << "socket closed prematurely: " << endl;
            cerr << strerror(errno) << endl;
            close(fd);
            close(socket_fd);
            return EXIT_FAILURE;
        } else if (writeRes == -1) {
            // failure
            cerr << "socket write failure: " << strerror(errno) << endl;
            close(fd);
            close(socket_fd);
            return EXIT_FAILURE;
        }
        assert(res == writeRes);
    }
    // successful!
    close(socket_fd);
    close(fd);
    return EXIT_SUCCESS;
}
