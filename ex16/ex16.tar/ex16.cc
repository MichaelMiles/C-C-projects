// Chenyang Fang
// 1663051
// chenyf@uw.edu
// Copyright 2018 Chenyang Fang
// program create TCP connection with
// the port number supplied by the user.
// listen read and output the data
// transfered from client to the stdout

#include <arpa/inet.h>
#include <assert.h>
#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>

#include "./listenHelper.h"

using namespace std;

int main(int argc, char** argv) {
    // expect the port number as a command line argument
    if (argc != 2) {
        Usage(argv[0]);
    }
    int listen_fd = Listen(argv[1]);
    if (listen_fd <= 0) {
        // failed
        cerr << "Could not bind to any addresses." << endl;
        return EXIT_FAILURE;
    }

    // Loop forever, accepting a connection from a client and
    // doing an echo trick to it
    while (1) {
      struct sockaddr_storage caddr;
      socklen_t caddr_len = sizeof(caddr);
      int client_fd = accept(listen_fd,
                                reinterpret_cast<struct sockaddr *>(&caddr),
                                &caddr_len);
      if (client_fd < 0) {
         if ((errno == EINTR) || (errno == EAGAIN) || (errno == EWOULDBLOCK))
            continue;
         std::cerr << "Failure on accept: " << strerror(errno) << std::endl;
         break;
      }
      // handle and break out of loop
      HandleClient(client_fd);
      break;
    }
    close(listen_fd);
    return EXIT_SUCCESS;
}
