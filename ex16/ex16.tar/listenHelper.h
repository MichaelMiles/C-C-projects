// Chenyang Fang
// 1663051
// chenyf@uw.edu
// Copyright 2018 Chenyang
// This header file defines some helper method for
// server-side net-work programming

#ifndef _LISTENHELPER_H_
#define _LISTENHELPER_H_

#include <arpa/inet.h>
#include <assert.h>
#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>

// with the given portnum,
// create a TCP listening socket on the port number
// and return the listen_fd on success
// on error, return -1
int Listen(char* portnum);

// With the given fd, listen and read data
// from the client and output the data to
// the stdout. On error, print out error message
// and exit
void HandleClient(int c_fd);

// Usage message
void Usage(char* progname);

#endif  // _LISTENHELPER_H_
